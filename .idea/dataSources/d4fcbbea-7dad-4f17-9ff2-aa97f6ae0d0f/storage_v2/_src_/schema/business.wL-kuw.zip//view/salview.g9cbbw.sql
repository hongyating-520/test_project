create definer = root@`%` view salview as
select `business`.`emp`.`ename` AS `ename`, `business`.`emp`.`empno` AS `empno`, `business`.`emp`.`sal` AS `sal`
from `business`.`emp`;

-- comment on column salview.ename not supported: 姓名

-- comment on column salview.empno not supported: 员工表

-- comment on column salview.sal not supported: 工资

